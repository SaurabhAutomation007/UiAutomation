﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace TestDemoOnNUnit1.StepDefinition
{
    [Binding]
    public class FeatureFile1StepDefinition
    {
        [Given(@"Open Edge browser")]
        public void GivenOpenEdgeBrowser()
        {
            
        }

    }
}
